# Load the CSV data
import csv

from sklearn.metrics import precision_recall_curve, auc

from predict_duplex_structure_3bps_MFE import pred_structure_get_total_score

sequences_1 = []
sequences_2 = []
labels = []

file_id_name = '../datasets/new_mmu_testset'
with open(f'{file_id_name}.csv', newline='') as csvfile:
    reader = csv.reader(csvfile)
    next(reader)
    for row in reader:
        sequences_1.append(row[0])
        sequences_2.append(row[1])
        labels.append(int(row[2]))

structure_scores = []
with open(f'{file_id_name}.sec_struct_3nts_MFE.out', 'w') as output_file:
    for idx, (seq1, seq2, label) in enumerate(zip(sequences_1, sequences_2, labels)):
        two_seqs, struct_dot_bracket, mfe_val, s_score_sigmoid, ML_model_score, traceback_matrix, rna_sequence_1, rna_sequence_2\
            = pred_structure_get_total_score(seq1, seq2)

        # Prepare the output in the desired format
        output_file.write(f">seq{idx+1} ML_score={ML_model_score:.3f} sec_score={s_score_sigmoid:.3f} label={label}\n")
        output_file.write(f"{two_seqs}\n")
        output_file.write(f"{struct_dot_bracket} ({mfe_val:.3f})\n")

        structure_scores.append(s_score_sigmoid)

# Calculate precision-recall curve and AUPRC
precision, recall, _ = precision_recall_curve(labels, structure_scores)
auprc = auc(recall, precision)

print(f"len of test set: {len(labels)}")
print(f"AUPRC: {auprc:.4f}")