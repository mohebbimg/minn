README
## How to Run the Source Codes

The provided source codes are written in Python and can be executed from the command line.

## datasets Folder Files

1. **test_set.csv**  
   - Contains the test set data. Each sample includes a microRNA sequence, a candidate target site (CTS) sequence, label, microRNA family, and MFE (MFE of secondary structure between the two sequences).

2. **training_set.csv**  
   - Contains the training set data, with the same structure as test_set.csv

3. **validation_set.csv**  
   - Contains the validation set data, with the same structure as test_set.csv

4. **test_set.sec_struct_3nts_MFE.out**  
   - The result of running `run_predictDuplexStructure3bps_MFE_on_testset.py` on `test_set.csv`.
   - The records of this file contains the secondary structure predicted by our DP algorithm.

5. **training_set.sec_struct_3nts_MFE.out**  
   - The result of running `run_predictDuplexStructure3bps_MFE_on_testset.py` on `training_set.csv`.

6. **validation_set.sec_struct_3nts_MFE.out**  
   - The result of running `run_predictDuplexStructure3bps_MFE_on_testset.py` on `validation_set.csv`.


### Running the Code:
Use the following command:
python filename.py


## Easiest Way to Run This Program on New Sequences

1. Prepare your data with the CSV format of our test_set.csv file. 
2. Split your data into two sets: training, validation and test sets.
3. Copy your training data into `training_set.csv`.
4. Copy your test data into `test_set.csv`.
5. Copy your validation data into `validation_set.csv`.

6. Run `run_predictDuplexStructure3bps_MFE_on_testset.py`:
  	- python run_predictDuplexStructure3bps_MFE_on_testset.py
	- This will create test_set.sec_struct_3nts_MFE.out
	- In the python file, change the file name to training_set.csv and run it.
	- Repeat the previous step for validation_set.csv as well.
 
5. Run `targetsite_pred_multi_input_NN_MINN.py`:
   	- python targetsite_pred_multi_input_NN_MINN.py
	- it will train your model, choose best parameters during validation, and predict label for test samples and store in a text file. Example: predictions_of_multi_input_model_2024-11-09_19-58-41.txt


### Source Code Files:

1. **run_predictDuplexStructure3bps_MFE_on_testset.py**  
   - Function: Predict secondary structure of duplex of microRNA and CTS sequences.
   - For an input csv file, for example test_set.csv, it generates test_set.sec_struct_3nts_MFE.out.
   - You need to run this program for training, validation, and test sets.

2. **targetsite_pred_multi_input_NN_MINN.py**  
   - Function: Reads `.out` and `.csv` files in datasets folder, trains the model, and test the model on the test set, and store the results in a text file.





